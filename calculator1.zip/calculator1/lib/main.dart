import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Calculator',
      theme: ThemeData(
        primaryColor: Colors.blue,
        scaffoldBackgroundColor: const Color.fromARGB(255, 255, 255, 255),
      ),
      home: const CalculatorScreen(),
    );
  }
}
class CalculatorScreen extends StatefulWidget {
  const CalculatorScreen({super.key});

  @override
  State<CalculatorScreen> createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen>{
  String _output = "0";        // สิ่งที่แสดงบนหน้าจอ
  String _currentNumber = "0"; // ตัวเลขที่กำลังพิมพ์
  double num1 = 0;             // ตัวเลขตัวแรก
  double num2 = 0;             // ตัวเลขตัวที่สอง
  String operand = "";         // เครื่องหมาย
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Calculator', style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.black,
      ),
      body: Column(
        children: <Widget>[
          Container(
            alignment: Alignment.centerRight,
            padding: const EdgeInsets.symmetric(vertical: 24.0, horizontal: 12.0),
            child: Text(
              _output,
              style: const TextStyle(fontSize: 60.0, fontWeight: FontWeight.bold, color: Color.fromARGB(255, 48, 48, 48)),
            ),
          ),
          
          const Expanded(child: Divider()),

          Column(
            children: [
              Row(children: [
                buildButton("7", Colors.grey[850]!, Colors.white),
                buildButton("8", Colors.grey[850]!, Colors.white),
                buildButton("9", Colors.grey[850]!, Colors.white),
                buildButton("/", Colors.orange, Colors.white),
              ]),
              Row(children: [
                buildButton("4", Colors.grey[850]!, Colors.white),
                buildButton("5", Colors.grey[850]!, Colors.white),
                buildButton("6", Colors.grey[850]!, Colors.white),
                buildButton("X", Colors.orange, Colors.white),
              ]),
              Row(children: [
                buildButton("1", Colors.grey[850]!, Colors.white),
                buildButton("2", Colors.grey[850]!, Colors.white),
                buildButton("3", Colors.grey[850]!, Colors.white),
                buildButton("-", Colors.orange, Colors.white),
              ]),
              Row(children: [
                buildButton(".", Colors.grey[850]!, Colors.white),
                buildButton("0", Colors.grey[850]!, Colors.white),
                buildButton("C", Colors.redAccent, Colors.white),
                buildButton("+", Colors.orange, Colors.white),
              ]),
              Row(children: [
                buildButton("=", Colors.orange, Colors.white),
              ]),
            ],
          )
        ],
      ),
    );
  }
  Widget buildButton(String buttonText, Color buttonColor, Color textColor) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.all(5.0),
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: buttonColor,
            shape: const CircleBorder(),
            padding: const EdgeInsets.all(20.0),
          ),
          child: Text(
            buttonText,
            style: TextStyle(fontSize: 30.0, fontWeight: FontWeight.bold, color: textColor),
          ),
          onPressed: () => buttonPressed(buttonText),
        ),
      ),
    );
  }
    void buttonPressed(String buttonText) {
    if (buttonText == "C") {

      _output = "0";
      _currentNumber = "0";
      num1 = 0;
      num2 = 0;
      operand = "";
    } else if (buttonText == "+" || buttonText == "-" || buttonText == "/" || buttonText == "X") {

      num1 = double.parse(_output);
      operand = buttonText;        
      _currentNumber = "0";         
    } else if (buttonText == "=") {

      num2 = double.parse(_output);


      if (operand == "+") _output = (num1 + num2).toString();
      if (operand == "-") _output = (num1 - num2).toString();
      if (operand == "X") _output = (num1 * num2).toString();
      if (operand == "/") _output = (num1 / num2).toString();


      num1 = 0;
      num2 = 0;
      operand = "";
      _currentNumber = _output;
    } else {

      if (_currentNumber == "0") {
        _currentNumber = buttonText;
      } else {
        _currentNumber = _currentNumber + buttonText; 
      }
      _output = _currentNumber; 
    }

    setState(() {});
  }
}
