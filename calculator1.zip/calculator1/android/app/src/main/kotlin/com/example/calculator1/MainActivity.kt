package com.example.calculator1

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
